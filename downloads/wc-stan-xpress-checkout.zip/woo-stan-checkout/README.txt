=== Stan Checkout ===
Contributors: jnser
Tags: stanapp, stan, paiement, paiement, checkout, 1-click
Requires at least: 5.0.0
Tested up to: 6.4.3
Stable tag: 1.0.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Boostez votre taux de conversion avec un checkout plus rapide. Faites plaisir à vos clients ! Optimisez vos ventes en ligne

Proposez l'achat Xpress en un clic à vos clients ! Les longs formulaires est la première raison qui vous fait perdre des clients, avec Stan Checkout vos clients bénéficient d'une meilleure expérience à l'achat.

== Description ==

Vous perdez des clients à cause du formulaire au checkout, il est long, il demande un effort à vos clients. Vous pouvez améliorer cette partie avec Stan Checkout.

= Stan est la meilleure expérience d'achat que vous pouvez proposer à vos clients ! =

Commencer à recevoir des paiements par Stan ne prend que quelques minutes. Il n’y a aucun frais dissimulé, et pas d’abonnement.

__Commencez maintenant!__

= Stan, c’est 3 min chrono =

Stan est facile à installer et ne nécessite pas d’intégration complexe. 

Une fois toutes vos informations réunies à la [création de compte](https://compte.stan-app.fr/signup), vous allez voir, c’est facile, rapide et efficace.

= Avec Stan, gagnez du temps =

Avec Stan, vous gagnez du temps, et vous faites aussi gagner du temps à vos clients ! 

Vous proposez un parcours post panier automatisé

Plus de formulaire, vos clients se souviendront de l'excellente expérience d’achat que vous leur proposez. 

Vous allez vous différencier. __Ils vont parler de vous !__

= Comment fonctionne Stan : Fast pay ? =

Lors d'une commande, le client sélectionne le bouton "Achat Xpress". Le client ne remplit aucune information. Toutes ses informations identité, emails, livraisons sont automatiquement remplies.

Après avoir passé la commande, le client recevra un email de confirmation.

= Quels sont les avantages de Stan ? =

En implémentant Stan, vous obtenez simplicité et flexibilité, pour vous et vos clients. 

Avec Stan vous pouvez offrir à vos clients la flexibilité de paiement rapide et efficace, vous obtenez la façon la plus simple d’implémenter et de gérer cette solution de paiement.

L’implémentation de Stan ne vous donne pas seulement un processus d’implémentation sans soucis, elle vous offre également des prix transparents et d’innombrables fonctionnalités pour tirer le meilleur parti de votre gestion financière.

= Honnêteté et transparence =

Pas de frais minimum ou de frais cachés, sans durée d'engagement contractuel.

= D’incroyables fonctionnalités =

Économisez un temps précieux grâce à nos fonctionnalités ! Connectez, protégez et développez votre entreprise plus efficacement.

== Service ==

Stan Checkout repose sur son service https://api.stan-app.fr. [Voir la documentation technique](https://doc.stan-app.fr).

Les paiements sont conforme à la PCI DSS.

== Installation ==

# DEPUIS VOTRE COMPTE ADMIN WORDPRESS

Sur https://votre-site.fr/wp-admin

1. Allez sur Extensions > Ajouter
2. Cherchez Stan Checkout, trouvez et installez Stan Checkout.
3. Activez le plugins depuis la page Extensions

# DEPUIS WORDPRESS.ORG

1. Téléchargez Stan Checkout
2. Dé-zippez and téléversez le dossier woo-stan-checkout dans `/wp-content/plugins/directory`
3. Activez Stan Checkout depuis la page des plugins

== F.A.Q. ==

= Comment je reçois l'argent ? =

Lorsque vous configurez le plugin Stan Checkout vous renseignez vos informations bancaires avec votre IBAN. Le montant lors d'un achat est directement viré vers votre compte bancaire.

= Est-ce sécurisé ? =

Les paiements réalisés avec Stan sont conforme à la PCI DSS

== Mises à jour ==

= 1.0 =
* Première version de Stan Xpress Checkout
