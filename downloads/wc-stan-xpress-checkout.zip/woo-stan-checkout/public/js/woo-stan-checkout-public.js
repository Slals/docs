(function( $ ) {
	'use strict';
	$( window ).on( 'load', function() {
		$( '.stan-checkout--button' ).on( 'click', function() {
			$( this ).toggleClass( 'stan-checkout--button-loading' );
			$( '.stan-checkout--error-text' ).css( 'visibility', 'hidden' );
			fetch('/wp-json/stan/checkouts', {
				method: 'POST',
				body: JSON.stringify({}),
				credentials: 'include',
			})
			.then(async res => {
				const checkout = await res.json();
				if (checkout.checkout_url) {
					window.location = checkout.checkout_url;
					return;
				}

				$( this ).toggleClass( 'stan-checkout--button-loading' );
				$( '.stan-checkout--error-text' ).css( 'visibility', 'visible' );
			})
			.catch(() => {
				$( this ).toggleClass( 'stan-checkout--button-loading' );
				$( '.stan-checkout--error-text' ).css( 'visibility', 'visible' );
			});
		});
	});
})( jQuery );
