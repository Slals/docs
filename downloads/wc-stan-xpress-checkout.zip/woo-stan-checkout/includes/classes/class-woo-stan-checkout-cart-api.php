<?php

namespace StanCheckout;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Manage checkout
 *
 * @since 1.0.0
 */
class WooStanCheckoutCartAPI {
	use StanCheckoutEndpointController;
    /**
	 * Constructor Function.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 */
	public function __construct() {
		if ( WOO_STAN_CHECKOUT_WP_REST_API_ADDON ) {
			add_filter( 'json_endpoints', array( $this, 'register_wp_rest_api_route' ) );
		} else {
			add_action( 'rest_api_init', array( $this, 'register_checkout_endpoint' ) );
		}
	}

    /**
	 * Register WP REST API route
	 *
	 * @param array $routes
	 *
	 * @return array
	 * @since  1.0.0
	 * @access public
	 *
	 */
	public function register_wp_rest_api_route( $routes ) {
		$routes['/stan/checkouts'] = array(
			array( array( $this, 'handle_create_checkout_api' ), 'POST' | \WP_JSON_Server::ACCEPT_JSON ),
		);
		$routes['/stan/checkouts'] = array(
			array(
				array( $this, 'handle_update_cart_api' ), 'POST' | \WP_JSON_Server::ACCEPT_JSON,
			),
		);
		
		return $routes;
	}

    /**
	 * Register wordpress endpoints
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 */
	public function register_checkout_endpoint() {
		register_rest_route( 'stan', '/checkouts', array(
			array(
                'methods' => 'POST',
                'callback' => array( $this, 'handle_create_checkout_api' ),
                'permission_callback' => '__return_true'
            )
		) );
		register_rest_route( 'stan', '/carts', array(
			array(
				'methods' => 'POST',
				'callback' => array( $this, 'handle_update_cart_api' ),
				'permission_callback' => '__return_true'
			)
		) );
	}

    /**
     * Handles customer API
     * 
     * @since 1.0.0
     */
    public function handle_create_checkout_api() {
		$this->handle_request_middleware();

		restore_session_from_session_id( $this->session_id );

		$client = new WooStanCheckoutAPIWrapper();

		try {
			$checkout = $client->create_checkout( $this->session_id, WC()->cart );
			return $checkout;
		} catch ( \Exception $e ) {
			return array(
				STAN_EVENT_RES_SUCCESS_FIELD => false
			);
		}

        return array(
			STAN_EVENT_RES_SUCCESS_FIELD => true,
			STAN_EVENT_RES_DATA_FIELD => $checkout
		);
    }

	/**
	 * Handles cart update API
	 * 
	 * @since 1.0.0
	 */
	public function handle_update_cart_api() {
		// TODO for updating cart items
		return array(
			STAN_EVENT_RES_SUCCESS_FIELD => false
        );
	}
}

new WooStanCheckoutCartAPI();