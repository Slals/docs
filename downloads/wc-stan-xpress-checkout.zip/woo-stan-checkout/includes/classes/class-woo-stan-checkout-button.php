<?php

namespace StanCheckout;

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    WooStanCheckout
 * @subpackage WooStanCheckout/includes/classes
 * @author     Brightweb <jonathan@brightweb.cloud>
 */
class WooStanCheckoutButton {

	/**
	 * @param $client_wrapper
	 */
	public function __construct(){
		$this->init();
	}

	/**
	 * Initiates the button configurations.
	 *
	 * @param $settings
	 * @param $client_wrapper
	 */
	public function init() {
		add_shortcode( STAN_BUTTON_SHORTCODE, array( $this, 'init_stan_checkout_button' ) );
		add_action( 'woocommerce_before_checkout_billing_form', array( $this, 'display_stan_checkout_button_in_checkout' ), 5 );
		add_action( 'woocommerce_before_cart_totals', array( $this, 'display_stan_checkout_button_in_cart_page' ), 5 );
		add_action( 'woocommerce_widget_shopping_cart_buttons', array( $this, 'display_stan_checkout_button_in_mini_cart_page' ), 10 );
	}

	/**
	 * Displays an error message to the user
	 *
	 * @param $error_code
	 *
	 * @return string
	 */
	public function make_error_output( $error_code, $error_message ) {
		ob_start();

		?>
		<div id="login_error">
			<strong><?php echo 'Erreur de connexion'; ?>: </strong>
			<?php print esc_html($error_message); ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Display Stan Checkout button in Woocommerce checkout page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function display_stan_checkout_button_in_checkout() {
		echo do_shortcode('[' . STAN_BUTTON_SHORTCODE . ' centered="true"]');
		echo '<h5 class="stan-checkout-text">—&nbsp;Ou&nbsp;compléter&nbsp;manuellement&nbsp;—</h5>';
		echo '<br />';
    }

	/**
	 * Display Stan Checkout button in Woocommerce cart page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function display_stan_checkout_button_in_cart_page() {
		echo do_shortcode('[' . STAN_BUTTON_SHORTCODE . ' to-right="true"]');
    }

	/**
	 * Display Stan Checkout button in Woocommerce mini cart page
	 * 
	 * @since 1.0.0
	 * @return void
	 */
	public function display_stan_checkout_button_in_mini_cart_page() {
		echo do_shortcode('[' . STAN_BUTTON_SHORTCODE . ' centered="true"]');
	}

	/**
	 * Creates a login button
	 *
	 * @return string
	 */
	public function init_stan_checkout_button( $atts ) {

		if ( isset( $_COOKIE[ STAN_SESSION_ID_COOKIE ] ) && WC()->cart ) {
			if ( isset( $attrs['product-id'] ) ) {
				add_filter( 'woocommerce_add_to_cart_redirect', '__return_empty_string' );
				WC()->cart->empty_cart();
				WC()->cart->add_to_cart( $attrs['product-id'] );
				remove_filter( 'woocommerce_add_to_cart_redirect', '__return_empty_string' );
			}
			WC()->cart->maybe_set_cart_cookies();
			WC()->session->set( STAN_SESSION_USER_ID, get_current_user_id() );
			
			save_session( $_COOKIE[ STAN_SESSION_ID_COOKIE ] );
		}

		$text = 'Achat Xpress';
		if ( wc_stan()->get_settings_instance()->is_testmode() ) {
			$text .= ' (mode test)';
		}
		
		$btn_class = 'stan-checkout--button' . (isset( $attrs['centered'] ) ? ' stan-checkout--centered' : '');
		$btn_class .= (isset( $attrs['to-right'] ) ? ' stan-checkout--to-right' : '');
		
		ob_start();

		?>
			<div id="stan-checkout">
				<button type="button" class="<?php echo $btn_class ?>">
					<span class="stan-checkout--button-text">
						<?php print $text; ?>
					</span>
				</button>
				<p class="stan-checkout--error-text">Impossible de procéder à l'achat express pour cette commande. Merci de nous contacter !</p>
			</div>
		<?php

		return ob_get_clean();
	}
}